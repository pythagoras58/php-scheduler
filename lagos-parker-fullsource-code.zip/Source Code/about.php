<?php require_once('check_login.php');?>
<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>
<?php include('connect.php');?>
<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>About Author</h4>


</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href=""> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Lagos Parker</a>
</li>
<li class="breadcrumb-item"><a href="about.php">About Author</a>
</li>
</ul>
</div>
</div>
</div>
</div>
<!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<div class="page-body">

<div class="card">
                       
                        <div class="card-body">
                            <table width="800" border="0" align="center" cellpadding="5">
            <tr>
                <td colspan="2"><b>Basic Info</b><hr/></td>
            </tr>
            <tr>
                <td width="50%" align="right">Name:</td>
                <td>Mayuri K.</td>
            </tr>
           
            <tr>
                <td align="right">Nationality:</td>
                <td>Indian</td>
            </tr>
            <tr>
                <td colspan="2"><b>Contact Details</b><hr/></td>
            </tr>
           
            <tr>
                <td align="right">Email & Hangout Address:</td>
                <td>mayuri.infospace@gmail.com</td>
            </tr>
           
            <tr>
                <td colspan="2"><b>Eduction & Knowledge</b><hr/></td>
            </tr>
             <tr>
                <td align="right">Education:</td>
                <td>Masters in Computer Science</td>
            </tr>
            <tr>
                <td align="right">Programming Language:</td>
                <td>PHP, Codeignitor and Laravel</td>
            </tr>
            <tr>
                <td colspan="2"><b>Work Experience</b> <hr/></td>
            </tr>
            <tr>
                <td align="right" valign="top">Doing Freelancing</td>
                <td> from last 4 Years<br/>
                
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>Note : </b><hr/></td>
            </tr>
            <tr>
                <td colspan="2"><h4><b>For students or anyone else who needs program or source code for thesis writing or <br><br>any Professional Software Development,Website Development,Mobile Apps Development <br><br>at affordable cost contact me at Email : mayuri.infospace@gmail.com</b></h4><hr/></td>
            </tr>
        </table>

                        </div>
                    </div>


</div>

</div>
</div>
<!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<div id="#">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include("footer.php"); ?>
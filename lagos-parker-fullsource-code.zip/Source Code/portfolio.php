<?php require_once('check_login.php');?>
<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>
<?php include('connect.php');?>
<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>Till Date I developed following Projects :</h4>


</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href=""> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Lagos Parker</a>
</li>
<li class="breadcrumb-item"><a href="portfolio.php">My Portfolio</a>
</li>
</ul>
</div>
</div>
</div>
</div>
<!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<div class="page-body">

<div class="card">
                       
                        <div class="card-body">
                            <table width="800" border="0" align="left" cellpadding="5">
            <h7><strong>Web Application</strong> :</h7><br><br>
            <tr>
            1.Advanced Online Examination System Admin Panel and Students Panel<br>
2.Garment Management System<br>
3.Hospital Management System<br>
4.Billing and Stock Management System<br>
5.Gym Manageemnt System<br>
6.Vaccination Management System<br>
7.Online Food Delivery - Front End with Admin Panel<br>
8.Business ERP System<br>
9.Multi level Marketing System<br>
10.Appoitment Management System<br>
11.Pharmacy Management System<br>
12.School Management System<br>
13.Phone Store Management System<br>
14.Software Development Office<br>

            </tr>
           
            
            <tr>
                <td colspan="4"><hr/></td>
            </tr>
           
            
           
            <tr>
                <td colspan="2"><b>Android Application</b><hr/></td>

            </tr>
             <tr>


             
                <td>1.Online Examination Android App<br>
2.Task Management App<br>
3.Staff Salary App<br>
4.Online Food Ordering App<br>
5.Android App like Just Dial<br>
</td>
            </tr>
              
            <tr>
                <td colspan="4"><hr/></td>
            </tr>
           
            
            <tr>
                <td colspan="2"><b>For students or anyone else who needs program or source code for thesis writing or any Professional Software Development,<br>Website Development,Mobile Apps Development at affordable cost contact me at Email : mayuri.infospace@gmail.com</b><hr/></td>
            </tr>
        </table>

                        </div>
                    </div>


</div>

</div>
</div>
<!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<div id="#">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include("footer.php"); ?>
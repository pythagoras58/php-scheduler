# Changelog

All notable changes to `Vue Material Dashboard Laravel`  will be documented in this file.

## Version 1.0.0

### Added
- Vue Material Dashboard Free
- Login
- Register
- Profile edit

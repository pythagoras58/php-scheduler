# Download

For the free version of the project you can either

 - download the .zip file from the Creative Tim site and extract it or
 - make a clone from the Github repository

You will get two project folders: one for the Laravel API project and one for the Vue frontend.
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Park Layout</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('inc/header.php');
						
	?>
	
	<section id="content">
	<img src="src/city.jpg" style="width:480px; border:solid 2px gray; margin:10px;display:inline;"/>
	<img src="src/pl.jpg" style="width:450px; border:solid 2px gray; margin:10px;display:inline;"/>
	</section>
	</section>
</body>
</html>